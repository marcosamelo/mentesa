export interface Exercise {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  type: 'memory' | 'logic' | 'attention' | 'language';
  completed: boolean;
}

export interface User {
  name: string;
  age: number;
  preferences: {
    highContrast: boolean;
    fontSize: 'normal' | 'large' | 'extra-large';
    soundEnabled: boolean;
  };
  progress: {
    exercisesCompleted: number;
    streak: number;
    lastActivity: Date;
  };
}