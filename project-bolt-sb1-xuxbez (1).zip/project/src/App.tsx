import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { MemoryGame } from './components/games/MemoryGame';
import { useStore } from './store';

function App() {
  const setUser = useStore((state) => state.setUser);

  useEffect(() => {
    // Simulate user login
    setUser({
      name: 'Maria',
      age: 65,
      preferences: {
        highContrast: false,
        fontSize: 'large',
        soundEnabled: true,
      },
      progress: {
        exercisesCompleted: 12,
        streak: 3,
        lastActivity: new Date(),
      },
    });
  }, [setUser]);

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="pt-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/memory-game" element={<MemoryGame />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;