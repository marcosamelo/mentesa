import React, { useState, useEffect } from 'react';
import { 
  Bird, Fish, Cat, Dog, Rabbit, 
  Bug, Squirrel, Bear, Trophy
} from 'lucide-react';
import { useStore } from '../../store';

const icons = [
  { id: 1, Icon: Bird, color: 'text-sky-500', name: 'Pássaro' },
  { id: 2, Icon: Fish, color: 'text-blue-500', name: 'Peixe' },
  { id: 3, Icon: Cat, color: 'text-gray-700', name: 'Gato' },
  { id: 4, Icon: Dog, color: 'text-amber-700', name: 'Cachorro' },
  { id: 5, Icon: Rabbit, color: 'text-pink-500', name: 'Coelho' },
  { id: 6, Icon: Bug, color: 'text-green-600', name: 'Inseto' },
  { id: 7, Icon: Squirrel, color: 'text-orange-600', name: 'Esquilo' },
  { id: 8, Icon: Bear, color: 'text-brown-700', name: 'Urso' }
];

interface Card {
  id: number;
  iconId: number;
  isFlipped: boolean;
  isMatched: boolean;
}

export function MemoryGame() {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const completeExercise = useStore(state => state.completeExercise);

  useEffect(() => {
    initializeGame();
  }, []);

  const initializeGame = () => {
    const duplicatedIcons = [...icons, ...icons];
    const shuffledCards = duplicatedIcons
      .sort(() => Math.random() - 0.5)
      .map((icon, index) => ({
        id: index,
        iconId: icon.id,
        isFlipped: false,
        isMatched: false,
      }));
    setCards(shuffledCards);
    setFlippedCards([]);
    setMoves(0);
    setIsComplete(false);
  };

  const handleCardClick = (cardId: number) => {
    if (flippedCards.length === 2 || cards[cardId].isMatched || cards[cardId].isFlipped) {
      return;
    }

    const newCards = [...cards];
    newCards[cardId].isFlipped = true;
    setCards(newCards);

    const newFlippedCards = [...flippedCards, cardId];
    setFlippedCards(newFlippedCards);

    if (newFlippedCards.length === 2) {
      setMoves(prev => prev + 1);
      const [firstCard, secondCard] = newFlippedCards;
      
      if (cards[firstCard].iconId === cards[secondCard].iconId) {
        setTimeout(() => {
          const updatedCards = [...newCards];
          updatedCards[firstCard].isMatched = true;
          updatedCards[secondCard].isMatched = true;
          setCards(updatedCards);
          setFlippedCards([]);

          if (updatedCards.every(card => card.isMatched)) {
            setIsComplete(true);
            completeExercise('1');
          }
        }, 500);
      } else {
        setTimeout(() => {
          const updatedCards = [...newCards];
          updatedCards[firstCard].isFlipped = false;
          updatedCards[secondCard].isFlipped = false;
          setCards(updatedCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  const getIcon = (iconId: number) => {
    const icon = icons.find(i => i.id === iconId);
    if (!icon) return null;
    const { Icon, color, name } = icon;
    return (
      <div className="flex flex-col items-center justify-center">
        <Icon className={`w-16 h-16 ${color}`} />
        <span className="text-sm mt-2 font-medium text-gray-600">{name}</span>
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Jogo da Memória</h1>
            <p className="text-gray-600 mt-2">Encontre os pares de animais correspondentes</p>
          </div>
          <div className="flex gap-4">
            <div className="bg-white px-4 py-2 rounded-lg shadow-md">
              <span className="text-gray-600">Jogadas: </span>
              <span className="font-bold text-indigo-600">{moves}</span>
            </div>
            <button
              onClick={initializeGame}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Reiniciar
            </button>
          </div>
        </div>

        {isComplete ? (
          <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="w-20 h-20 text-yellow-500" />
            </div>
            <h2 className="text-2xl font-bold text-green-800 mb-2">
              Parabéns! Você completou o jogo!
            </h2>
            <p className="text-green-600 mb-4">
              Você completou o jogo em {moves} jogadas!
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={initializeGame}
                className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
              >
                Jogar Novamente
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-4 gap-6">
            {cards.map((card) => (
              <button
                key={card.id}
                onClick={() => handleCardClick(card.id)}
                className={`aspect-square rounded-xl transition-all duration-300 transform ${
                  card.isFlipped || card.isMatched
                    ? 'bg-white rotate-0'
                    : 'bg-indigo-600 rotate-y-180'
                } shadow-md hover:shadow-lg flex items-center justify-center p-4`}
                disabled={card.isMatched}
              >
                {(card.isFlipped || card.isMatched) && getIcon(card.iconId)}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}