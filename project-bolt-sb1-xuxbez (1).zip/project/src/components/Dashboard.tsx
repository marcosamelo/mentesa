import React from 'react';
import { Activity, Brain, Calendar, Trophy } from 'lucide-react';
import { useStore } from '../store';
import { ExerciseCard } from './ExerciseCard';

export function Dashboard() {
  const { user, exercises } = useStore();

  const stats = [
    {
      icon: <Trophy className="w-6 h-6 text-yellow-500" />,
      label: 'Exercícios Completados',
      value: user?.progress.exercisesCompleted || 0,
    },
    {
      icon: <Calendar className="w-6 h-6 text-green-500" />,
      label: 'Dias Seguidos',
      value: user?.progress.streak || 0,
    },
    {
      icon: <Brain className="w-6 h-6 text-purple-500" />,
      label: 'Pontuação Total',
      value: (user?.progress.exercisesCompleted || 0) * 100,
    },
    {
      icon: <Activity className="w-6 h-6 text-blue-500" />,
      label: 'Nível Atual',
      value: Math.floor((user?.progress.exercisesCompleted || 0) / 5) + 1,
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gray-50 rounded-lg">{stat.icon}</div>
              <div>
                <p className="text-sm text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <h2 className="text-2xl font-bold mb-6">Exercícios Disponíveis</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {exercises.map((exercise) => (
          <ExerciseCard
            key={exercise.id}
            exercise={exercise}
            onSelect={(ex) => console.log('Selected exercise:', ex)}
          />
        ))}
      </div>
    </div>
  );
}