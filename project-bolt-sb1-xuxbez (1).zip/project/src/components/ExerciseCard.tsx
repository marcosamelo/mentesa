import React from 'react';
import { ArrowRight, Trophy } from 'lucide-react';
import { Exercise } from '../types';
import { useNavigate } from 'react-router-dom';

interface ExerciseCardProps {
  exercise: Exercise;
  onSelect: (exercise: Exercise) => void;
}

export function ExerciseCard({ exercise, onSelect }: ExerciseCardProps) {
  const navigate = useNavigate();
  
  const difficultyColors = {
    easy: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    hard: 'bg-red-100 text-red-800',
  };

  const handleClick = () => {
    if (exercise.type === 'memory') {
      navigate('/memory-game');
    } else {
      onSelect(exercise);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="p-6">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-semibold mb-2">{exercise.title}</h3>
          {exercise.completed && (
            <Trophy className="w-6 h-6 text-yellow-500" />
          )}
        </div>
        <p className="text-gray-600 mb-4">{exercise.description}</p>
        <div className="flex justify-between items-center">
          <span className={`px-3 py-1 rounded-full text-sm ${difficultyColors[exercise.difficulty]}`}>
            {exercise.difficulty.charAt(0).toUpperCase() + exercise.difficulty.slice(1)}
          </span>
          <button
            onClick={handleClick}
            className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 transition-colors"
          >
            Começar
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}