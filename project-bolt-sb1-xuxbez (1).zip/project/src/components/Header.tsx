import React from 'react';
import { Brain, Settings } from 'lucide-react';
import { useStore } from '../store';

export function Header() {
  const user = useStore((state) => state.user);

  return (
    <header className="bg-indigo-600 text-white p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Brain className="w-8 h-8" />
          <h1 className="text-2xl font-bold">MenteSã</h1>
        </div>
        
        <div className="flex items-center gap-4">
          {user && (
            <div className="text-lg">
              Olá, {user.name}
            </div>
          )}
          <button
            className="p-2 hover:bg-indigo-700 rounded-full transition-colors"
            aria-label="Configurações"
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
}