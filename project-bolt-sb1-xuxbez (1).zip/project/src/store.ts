import { create } from 'zustand';
import { User, Exercise } from './types';

interface AppState {
  user: User | null;
  exercises: Exercise[];
  setUser: (user: User) => void;
  togglePreference: (key: keyof User['preferences']) => void;
  completeExercise: (exerciseId: string) => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  exercises: [
    {
      id: '1',
      title: 'Jogo da Memória',
      description: 'Encontre os pares de cartas correspondentes',
      difficulty: 'easy',
      type: 'memory',
      completed: false,
    },
    {
      id: '2',
      title: 'Quebra-cabeça Numérico',
      description: 'Organize os números em ordem crescente',
      difficulty: 'medium',
      type: 'logic',
      completed: false,
    },
    {
      id: '3',
      title: 'Palavras Cruzadas',
      description: 'Complete as palavras cruzadas com temas do dia a dia',
      difficulty: 'medium',
      type: 'language',
      completed: false,
    },
  ],
  setUser: (user) => set({ user }),
  togglePreference: (key) =>
    set((state) => ({
      user: state.user
        ? {
            ...state.user,
            preferences: {
              ...state.user.preferences,
              [key]: !state.user.preferences[key],
            },
          }
        : null,
    })),
  completeExercise: (exerciseId) =>
    set((state) => ({
      exercises: state.exercises.map((ex) =>
        ex.id === exerciseId ? { ...ex, completed: true } : ex
      ),
      user: state.user
        ? {
            ...state.user,
            progress: {
              ...state.user.progress,
              exercisesCompleted: state.user.progress.exercisesCompleted + 1,
              lastActivity: new Date(),
            },
          }
        : null,
    })),
}));